﻿using Lombard_Goryacheva.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard_Goryacheva
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
     
        public MainWindow()
        {
            InitializeComponent();
        }
        public string strLoginUsers;
        public string strPasswordUsers;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Logtb.Clear();
            Passtb.Clear();
        }

        private void Enterbth_Click(object sender, RoutedEventArgs e)
        {
            Model.LombardEntities lombardEntities = Helper.GetContext();
            strPasswordUsers = Passtb.Text;
            strLoginUsers = Logtb.Text;
            if (!string.IsNullOrEmpty(strLoginUsers) && !string.IsNullOrEmpty(strPasswordUsers))
            {
                var findUsersAccount = lombardEntities.Sotrudnik.Where(x => x.Login == strLoginUsers && x.Password == strPasswordUsers).FirstOrDefault();
                if (findUsersAccount != null)
                {
                    View.Window1 Window = new View.Window1();
                    Window.Show();
                    this.Close();
                    MessageBox.Show("Вход выполнен");
                }
                else
                {
                    var log = lombardEntities.Sotrudnik.Where(x => x.Login == strLoginUsers).FirstOrDefault();
                    var psw = lombardEntities.Sotrudnik.Where(x => x.Password == strPasswordUsers).FirstOrDefault();

                    if (log == null)
                    {
                        MessageBox.Show("Неверный логин");
                    }
                    if (psw == null)
                    {
                        MessageBox.Show("Неверный пароль");
                    }
                }
            }
            else
            {
                MessageBox.Show("Введены не все данные");
            }
        }

    }
}

