package com.example.goryachevataxi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Sigh_Up extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sigh_up);
    }
}